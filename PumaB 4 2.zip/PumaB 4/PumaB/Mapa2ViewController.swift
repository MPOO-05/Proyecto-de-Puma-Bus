//
//  Mapa2ViewController.swift
//  PumaB
//
//  Created by macbookUser on 05/06/18.
//  Copyright © 2018 Facultad de ingenieria. All rights reserved.
//
import UIKit
import MapKit
import CoreLocation // para la ubicacion del usuario
import Firebase
import FirebaseDatabase

class Mapa2ViewController: UIViewController,MKMapViewDelegate, CLLocationManagerDelegate{
    
    var emailfirebase : String = " "
    
    var ref : DatabaseReference!
    
    @IBOutlet weak var Mapa2: MKMapView!
    var LocationManager : CLLocationManager?
    var location : CLLocation?
    var lastLocationError : Error?
    var updatingLocation = false
    var center1 = CLLocationCoordinate2D()
    var center2 = CLLocationCoordinate2D()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Mapa2.showsUserLocation = true
          ref = Database.database().reference()
        print(emailfirebase)
        
        if CLLocationManager.locationServicesEnabled() == true {
            if CLLocationManager.authorizationStatus() == .restricted || CLLocationManager.authorizationStatus() == .denied || CLLocationManager.authorizationStatus() == .notDetermined{
                
                LocationManager?.requestWhenInUseAuthorization()
            }
            
            
            LocationManager = CLLocationManager()
            LocationManager?.delegate = self
            LocationManager?.startUpdatingLocation()
            
            LocationManager?.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
          
            
        }else{
            
            print("Prende tu GPS")
        }
        
        self.Mapa2.delegate = self
        
        // Do any additional setup after loading the view.
    
        
        
        
        if(rutaSelec == 1){
            center2.latitude = 19.3308
            center2.longitude = -99.1808
            
            let region1 = MKCoordinateRegion(center:center2 , span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02))
            self.Mapa2.setRegion(region1, animated: true)
            
            
            for n in rutaN1 {
                let base1 = MKPointAnnotation()
                
                base1.title = dicBases[n]?.2
                base1.coordinate = CLLocationCoordinate2D(latitude: dicBases[n]?.0 as! Double, longitude: dicBases[n]?.1 as! Double)
                Mapa2.addAnnotation( base1)
                
            }
            
            
self.Mapa2.delegate = self
        }
       
        if(rutaSelec == 9){
            center2.latitude = 19.3308
            center2.longitude = -99.1845
            let region1 = MKCoordinateRegion(center:center2 , span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02))
            self.Mapa2.setRegion(region1, animated: true)
            
            
            for n in rutaN1 {
                let base1 = MKPointAnnotation()
                
                base1.title = dicBases[n]?.2
                base1.coordinate = CLLocationCoordinate2D(latitude: dicBases[n]?.0 as! Double, longitude: dicBases[n]?.1 as! Double)
                Mapa2.addAnnotation( base1)
                
            }
            
            
            
        }
        
        var emailfirebase2 = ""
        for r in emailfirebase {
            if (r == "."){
                emailfirebase2 = emailfirebase2 + ","
            }else{
                emailfirebase2 = emailfirebase2 + String(r)
            }
        }
        print(emailfirebase2)
        
        if emailfirebase != " "{
            let UserId = String(emailfirebase2)
            let SrutaSelect = "ruta" + String(rutaSelec)
            let Gps = ["lat": 0.0, "long": 0.0]
            
            self.ref.child("rutas").child(SrutaSelect).child(UserId).updateChildValues(Gps){ (error, databaseRef) in
                if error != nil{
                    print("error en base de datos")
                    return
                }
                print("localización actualizada")
            }
            
        

            
        }
        
        
        
        // Do any additional setup after loading the view.
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error ", error.localizedDescription)
        
        // localidad desconocida, estas perdido o el usuario no quizo dar permisos o hay un error en la red
        if (error as NSError).code == CLError.locationUnknown.rawValue{
            return
        }
        
        lastLocationError = error
        if updatingLocation {
            LocationManager?.stopUpdatingLocation()
            LocationManager?.delegate = nil
            updatingLocation = false
        }
    }
    
    
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        
        var speed: CLLocationSpeed = CLLocationSpeed()
        speed = (LocationManager?.location?.speed)!
        
        print(speed);
        
        
        center1.latitude = locations[0].coordinate.latitude
        center1.longitude = locations[0].coordinate.longitude
        
        
        let region = MKCoordinateRegion(center: center1, span: MKCoordinateSpan(latitudeDelta: 0.0001, longitudeDelta:0.001))
        
        self.Mapa2.setRegion(region, animated:false )
        
        // Imprime la coordenadas del usuario
        
        print(" Lat: \(center1.latitude) y Long \(center1.longitude) ")
        
        let newLocation = locations.last!
        print("didUpdateLocations ", newLocation)
        
        if newLocation.timestamp.timeIntervalSinceNow < -5 {
            return
        }
        
        location = newLocation
        lastLocationError = nil
        
        var emailfirebase2 = ""
        for r in emailfirebase {
            if (r == "."){
                emailfirebase2 = emailfirebase2 + ","
            }else{
                emailfirebase2 = emailfirebase2 + String(r)
            }
        }
       
        if let location = location{
            let latitude = String(format: "%.8f", location.coordinate.latitude)
            let longitude = String(format: "%.8f", location.coordinate.longitude)
            let idUser = emailfirebase2
            
            let valuesGPS = ["velocidad": String(speed),"lat":latitude, "long":longitude] as [String : Any]
            self.ref.child("rutas").child("ruta\(rutaSelec)").child("\(idUser)").updateChildValues(valuesGPS){ (error, databaseRef) in
                if error != nil{
                    print("error en base de datos")
                    return
                }
                print("localización actualizada")
            }
            
        }
        
    
        
        
        
        
    }
    
    
    
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus){
        if status == .authorizedWhenInUse || status == .authorizedAlways{
            LocationManager?.startUpdatingLocation()
            //LocationManager?.allowsBackgroundLocationUpdates = true
        }
   
    }
        
    
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
