

import UIKit
import Parse

class ViewController: UIViewController {
    

    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    var actInd: UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRect(x: 0, y: 0, width: 150, height: 150)) as UIActivityIndicatorView
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.actInd.center = self.view.center
        self.actInd.hidesWhenStopped = true
        self.actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
        
        view.addSubview(self.actInd)
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func loginAction(_ sender: Any) {
        var username = self.usernameField.text
        var password = self.passwordField.text
        //Establece el minimo de caracteres necesarios para crear la cuenta
        if (username!.characters.count) < 5 || (password!.characters.count < 5)
        {
            var alert = UIAlertView(title: "Inválido", message: "El Nombre de Usuario y la Contraseña deben tener al menos 5 caracteres", delegate: self, cancelButtonTitle: "ok")
            
                alert.show()
        }
        else{
            self.actInd.startAnimating()
            
            PFUser.logInWithUsername(inBackground: username!, password: password!, block: {(user, error) -> Void in self.actInd.stopAnimating()
                
                if ((user) != nil){
                    var alert = UIAlertView(title: "Bienvenido", message: "Estás dentro", delegate: self, cancelButtonTitle: "OK")
                    
                    alert.show()
                    
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "Home")
                    self.present(vc!, animated: true, completion: nil)
                }
                else{
                    var alert = UIAlertView(title: "Error", message: "Revisa parámetros e intenta de nuevo", delegate: self, cancelButtonTitle: "OK")
                    alert.show()
                }
            })
        }
    }
    
    
    @IBAction func signUpAction(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "Signup")
        self.present(vc!, animated: true, completion: nil)

    }
    
    func autoLogin(){
        
        if PFUser.current() == nil{
            print ("Usuario no existente")
        }
        else{
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "Home")
            self.present(vc!, animated: true, completion: nil)
        }
    }
    
    // Oculta el teclado al presionar fuera de los textfield
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            self.view.endEditing(true)
            
            super.touchesBegan(touches, with: event)
        }
    }
    
}

