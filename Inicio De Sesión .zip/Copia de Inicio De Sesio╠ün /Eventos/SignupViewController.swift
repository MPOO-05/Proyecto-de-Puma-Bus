

import UIKit
import Parse

class SignupViewController: UIViewController {

    
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    var actInd: UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRect(x: 0, y: 0, width: 150, height: 150)) as UIActivityIndicatorView

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.actInd.center = self.view.center
        self.actInd.hidesWhenStopped = true
        self.actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
        
        view.addSubview(self.actInd)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func signUpAction(_ sender: Any) {
        
        var username = usernameField.text
        var email = emailField.text
        var password = passwordField.text
        
        if (username!.characters.count) < 5 || (password!.characters.count < 5)
        {
            var alert = UIAlertView(title: "Inválido", message: "El nombre de usuario y la contraseña deben tener al menos 5 caracteres", delegate: self, cancelButtonTitle: "ok")
            alert.show()
        }
        
        else if (email!.characters.count < 8) {
            var alert = UIAlertView(title: "Correo inválido", message: "Introduce una dirección de correo válida", delegate: self, cancelButtonTitle: "Ok")
            alert.show()
        }
        
        else {
            self.actInd.startAnimating()
            var newUser = PFUser()
            newUser.username = username
            newUser.password = password
            newUser.email = email
            
            newUser.signUpInBackground(block: { (succeed, error) -> Void in
                self.actInd.stopAnimating()
                
                if ((error) != nil){
                    var alert = UIAlertView(title: "Error", message: "\(error)", delegate: self, cancelButtonTitle: "Ok")
                    alert.show()
                }
                else{
                    var alert = UIAlertView(title: "Bienvenido", message: "Estás dentro", delegate: self, cancelButtonTitle: "Ok")
                    alert.show()
                    
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "Home")
                    self.present(vc!, animated: true, completion: nil)
                }
            })
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
