//: Playground - noun: a place where people can play

import UIKit
// base de datos fija de las paradas de los pumabuses 1 a 53
let dicBases = [1:(19.3244,-99.1748,"Módulo Metro Universidad",true),
                2:(19.3282,-99.1749,"CENDI",true),
                3:(19.3323,-99.1784,"Psiquiatría y salud mental",true),
                4:(19.3308,-99.1808,"Facultad de Química",true),
                5:(19.3308,-99.1834,"CELE",true),
                6:(19.3308,-99.1845,"Facultad de Ingeniería",true),
                7:(19.3305,-99.1868,"Facultad de Arquitectura",true),
                8:(19.3327,-99.1894,"Rectoría",true),
                9:(19.3345,-99.1891,"Facultad de psicología",true),
               10:(19.3346,-99.1878,"Facultad de Filosofía",true),
               11:(19.3351,-99.1851,"Facultad de Derecho",true),
               12:(19.3352,-99.1830,"Facultad de Economía",true),
               13:(19.3349,-99.1808,"Facultad de Odontología",true),
               14:(19.3330,-99.1788,"Facultad de Medicina",true),
               21:(19.3236,-99.1847,"Facultad de Contaduría y Administración",true),
               22:(19.3233,-99.1867,"Escuela de Trabajo Social",true),
               23:(19.3243,-99.1877,"Metrobus CU",true),
               47:(19.3301,-99.1891,"MUCA",true),
               44:(19.3291,-99.1797,"Invernadero",true),
               45:(19.3271,-99.1809,"Camino Verde",true),
               46:(19.3257,-99.1819,"Anexo de Ingeniería",true),
               54:(19.3267,-99.1881,"Estadio de Prácticas",true),
                
]

let ruta1 = [1,2,3,4,5,6,7,8,9,10,11,12,13,14]
let ruta9 = [23,54,47,8,9,10,11,12,13,14,44,46,21,22]


let ubicacion = ["Usua":(19.3255,-99.1817)]




//
func distanciaCorta ( ruta: Int ){
    var latx  = 0.002
    var longy  = 0.003
    var temp = 0.0001
    
    var baseCercana = 1
    if (ruta == 1){
        for x in 0...(ruta1.count)-1{
            
            latx = dicBases[ruta1[x]]!.0
            longy = dicBases[ruta1[x]]!.1
             var distancia = ((latx - ubicacion["Usua"]!.0 ) * (latx - ubicacion["Usua"]!.0 )) + ((longy - ubicacion["Usua"]!.1 )*(longy - ubicacion["Usua"]!.1 ))
            distancia = sqrt(distancia)
            print("base\(ruta1[x]): \(latx),\(longy) distancia: \(distancia)")
            
        }
        
        
    }
    if (ruta == 9){
       for x in 0...(ruta9.count)-1{
        
        
           latx = dicBases[ruta9[x]]!.0
           longy = dicBases[ruta9[x]]!.1
            var distancia = ((latx - ubicacion["Usua"]!.0 ) * (latx - ubicacion["Usua"]!.0 )) + ((longy - ubicacion["Usua"]!.1 )*(longy - ubicacion["Usua"]!.1 ))
           distancia = sqrt(distancia)
        
           if (x == 0){
             temp = distancia
            
           }
        
           if (temp > distancia){
            
            
               temp = distancia
               baseCercana = x
           }
        
           print("base\(ruta9[x]): \(latx),\(longy) distancia: \(distancia)")
       }
    }
    print("base\(ruta9[baseCercana]): distancia : \(temp)")
    return
}

//distanciaCorta(ruta: 9)
distanciaCorta(ruta: 9)


