//
//  RegistroViewController.swift
//  PumaB
//
//  Created by Macbook on 6/5/18.
//  Copyright © 2018 Facultad de ingenieria. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class RegistroViewController: UIViewController {
    
    var ref = DatabaseReference()
   
    @IBOutlet weak var nombreC: UITextField!
    
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var contraseña: UITextField!
    
    @IBOutlet weak var contraseñaV: UITextField!
    
  
    override func viewDidLoad() {
        super.viewDidLoad()
ref = Database.database().reference()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func Registrar(_ sender: Any) {
        
        if let email = email.text, let password = contraseña.text, let passwordV = contraseñaV.text{
            
            if (password == passwordV && password.count>5 ){
                Auth.auth().createUser(withEmail: email, password: password){ (user, error) in
                    if user != nil {
                        print("Usuario Creado")
                        
                        let values = ["email" : email,"nombre": self.nombreC.text!]
                        
                        guard let uid = user?.uid else{return}
                        
                        let userReference  = self.ref.child("users").child(uid)
                        //si existe lo actualiza sino lo creo
                        //self.ref.update....
                        userReference.updateChildValues(values, withCompletionBlock: { (error, databaseRef) in
                            if error != nil{
                                print("Error al insertar el valor")
                                return
                                
                            }else{
                                print("Todo salio bien y se guardaron nada mas")
                                let vc = self.storyboard?.instantiateViewController(withIdentifier: "sesion")
                                self.present(vc!, animated: true, completion: nil)
                            }
                        })
                    }else{
                        if let error = error?.localizedDescription{
                            print("Error de firebase al crear usuario")
                            var alert = UIAlertView(title: "Inválido", message: "El correo que uso ya esta registrado", delegate: self, cancelButtonTitle: "ok")
                            alert.show()
                        }else{
                            print("El error fui Yo :/")
                        }
                    }
                }
            }else{
                var alert = UIAlertView(title: "Inválido", message: "La contraseña deben tener al menos 6 caracteres", delegate: self, cancelButtonTitle: "ok")
                alert.show()
            }
        }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
}
