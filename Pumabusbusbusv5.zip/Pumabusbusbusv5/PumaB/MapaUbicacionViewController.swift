//
//  MapaUbicacionViewController.swift
//  PumaB
//

/*
 /* Mapa.removeAnnotation(self.pumaBus)
 pumaBus.title = "Puma bus"
 pumaBus.coordinate = CLLocationCoordinate2D(latitude: locations[0].coordinate.latitude, longitude: locations[0].coordinate.longitude)
 */
 
 // Mapa.addAnnotation(pumaBus)
 
 */

//  Created by Macbook on 6/5/18.
//  Copyright © 2018 Facultad de ingenieria. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation // para la ubicacion del usuario
import Firebase

class MapaUbicacionViewController: UIViewController,MKMapViewDelegate, CLLocationManagerDelegate {
    var ref : DatabaseReference!
    var handler : DatabaseHandle!
    var email = " "
    var temporal = [GpsPumaBus]()
    @IBOutlet weak var Mapa: MKMapView!
    @IBOutlet var boton1: UIButton!
    var LocationManager = CLLocationManager()
    var location: CLLocation?
    var updatingLocation = false
    var lastLocationError: Error?
    var center1 = CLLocationCoordinate2D()
    var center2 = CLLocationCoordinate2D()
    var center3 = CLLocationCoordinate2D()
    var center4 = CLLocationCoordinate2D()
    let base1 = MKPointAnnotation()
    let pumaBus = MKPointAnnotation()
    let pumaBus2 = MKPointAnnotation()
    
    //------------------
    var velPromedio = 0.00

    
    
    @IBAction func ruta1(_ sender: Any) {
            if (rutaSelec > 0){self.ref.child("rutas").child("ruta\(rutaSelec)").removeAllObservers()}
            boton1.isEnabled = true
            boton1.backgroundColor = UIColor.green
            rutaSelec = 1
            viewDidLoad()
            center2.latitude = 19.3308
            center2.longitude = -99.1808
            let region1 = MKCoordinateRegion(center:center2 , span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02))
            self.Mapa.setRegion(region1, animated: true)
            Mapa.removeAnnotations(Mapa.annotations)
        
            for n in rutaN1 {
                let base1 = MKPointAnnotation()
                base1.title = dicBases[n]?.2
                base1.coordinate = CLLocationCoordinate2D(latitude: dicBases[n]?.0 as! Double, longitude: dicBases[n]?.1 as! Double)
                Mapa.addAnnotation( base1)
            }
            Mapa.tintColor = UIColor.green
            viewDidLoad()
    }
   
    @IBAction func ruta9(_ sender: Any) {
        //self.ref.child("child").removeAllObservers()
        //ref.child("rutas").child("ruta\(rutaSelec)").observe
            if (rutaSelec > 0){self.ref.child("rutas").child("ruta\(rutaSelec)").removeAllObservers()}
            rutaSelec = 9
            viewDidLoad()
            boton1.isEnabled = true
            boton1.backgroundColor = UIColor.green
            center2.latitude = 19.3308
            center2.longitude = -99.1845
            let region1 = MKCoordinateRegion(center:center2 , span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02))
            self.Mapa.setRegion(region1, animated: true)
            Mapa.removeAnnotations(Mapa.annotations)
        
            for n in rutaN9 {
                let base1 = MKPointAnnotation()
                base1.title = dicBases[n]?.2
                base1.coordinate = CLLocationCoordinate2D(latitude: dicBases[n]?.0 as! Double, longitude: dicBases[n]?.1 as! Double)
                Mapa.addAnnotation( base1)
            }
           Mapa.tintColor = UIColor.red
           viewDidLoad()
    }
    
    @IBAction func voyenpuma(_ sender: Any) {
    //print(rutaSelec)
    self.performSegue(withIdentifier: "segueMapa2", sender: self)
        
        if borraEnvioCoor == true {
            borraEnvioCoor = false
            let idUser = Auth.auth().currentUser?.uid
            print("borrando informacion")
            let valuesGPS = ["velocidad": nil, "lat": nil, "long": nil] as [String : Any?]
            self.ref.child("rutas").child("ruta\(rutaAnt)").child("\(idUser!)").updateChildValues(valuesGPS){ (error, databaseRef) in
                if error != nil{
                    print("error en base de datos")
                    return
                }
                
                
                
            }
        }
        
        
        
        
    }
    
    //-------------------------------------------------------------------------------------------------------------------------
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(email)
        print(rutaSelec)
        
        ref = Database.database().reference()
        
        
        Mapa.showsUserLocation = true
        
        if CLLocationManager.locationServicesEnabled() == true {
            if CLLocationManager.authorizationStatus() == .restricted || CLLocationManager.authorizationStatus() == .denied || CLLocationManager.authorizationStatus() == .notDetermined{
                LocationManager.requestWhenInUseAuthorization()
            }
            
            LocationManager.desiredAccuracy = 1.0
            LocationManager.delegate = self
            LocationManager.startUpdatingLocation()
            
         }else{
            
            print("Prende tu GPS")
         }
        
        self.Mapa.delegate = self
        
        if rutaSelec != 0 {
             print("---------------- Load")
             print(self.temporal.count)
             handler = ref.child("rutas").child("ruta\(rutaSelec)").observe(DataEventType.value, with: { (snapshot) in
               print(snapshot)
               self.temporal.removeAll()
               for user in snapshot.children.allObjects as! [DataSnapshot]{
                      let data = user.value as? [String: String]
                      //self.ref.removeAllObservers()
                      //print(data)
                      if let lat = data!["lat"], let long = data!["long"], let velocidad = data!["velocidad"]{
                            self.temporal.append(GpsPumaBus(lat: lat, long: long, velocidad : velocidad))
                            print("---------------------------------------------------- temporal")
                            print(self.temporal)
                            print("---------------------------------------------------- temporal")
                            //print(snapshot)
                       }
                 }
                
                print("--------acciones con el areglo de Temporal------- ")
                if (self.temporal.count > 0){
                    for m in 0...self.temporal.count {
                        if m == 0 {
                            self.center3.latitude = Double(self.temporal[0].lat)!
                            self.center3.longitude = Double(self.temporal[0].long)!
                            
                        }
                        if m == 1 {
                            self.center4.latitude = Double(self.temporal[1].lat)!
                            self.center4.longitude = Double(self.temporal[1].long)!
                            
                        }
                    }
                    
                }
                
                
                
            
                self.Mapa.removeAnnotation(self.pumaBus)
                self.pumaBus.title = "Puma bus"
                
                self.pumaBus.coordinate = CLLocationCoordinate2D(latitude: self.center3.latitude, longitude: self.center3.longitude)
                print(self.pumaBus.coordinate.latitude)
                
                
                
                self.Mapa.removeAnnotation(self.pumaBus2)
                self.pumaBus2.title = "Puma bus"
                
                self.pumaBus2.coordinate = CLLocationCoordinate2D(latitude: self.center4.latitude, longitude: self.center4.longitude)
                print(self.pumaBus2.coordinate.longitude)
                
                self.Mapa.addAnnotation(self.pumaBus2)
                //let region2 = MKCoordinateRegion(center: self.center4, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta:0.01))
                
                self.Mapa.addAnnotation(self.pumaBus)
                let region1 = MKCoordinateRegion(center: self.center3, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta:0.01))
                
                self.Mapa.setRegion(region1, animated:true )
                
                
                print("----------fin de acciones  en temporal -----------")
                
                //self.Mapa.setRegion(region2, animated:true )
                
             })
            

        }else {
            boton1.isEnabled = false
            boton1.backgroundColor = UIColor.red
        }
        
       
        
        
    }
    //-------------------------------------------------------------------------------------------------------------------------
   
//    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//
//        //center1.latitude = locations[0].coordinate.latitude
//        //center1.longitude = locations[0].coordinate.longitude
//
//
//        let region = MKCoordinateRegion(center: center1, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta:0.01))
//
//        self.Mapa.setRegion(region, animated:false )
//
//        // Imprime la coordenadas del usuario
//
//        print(" Lat: \(center1.latitude) y Long \(center1.longitude) ")
//        print(self.temporal.count)
//
//        print("ruta elejida\(rutaSelec)")
//
//
//
//
//   }
//    //funcion por si hay algun error
//
//    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
//        print("Hay un error")
//    }
    


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segueMapa2"{
            let siguienteVista = segue.destination as! Mapa2ViewController
            siguienteVista.emailfirebase =  String(email)
            
        }
    }
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        print(annotation.title)
        if annotation is MKUserLocation {
            return nil
            
        }
        
        
        
        
        if annotation.title == "Puma bus"{
            let pinPuma = "pinPuma"
            var annotationID : MKAnnotationView?
            if let vistanotation = mapView.dequeueReusableAnnotationView(withIdentifier: pinPuma){
                annotationID = vistanotation
                annotationID?.annotation = annotation
                
            }else{
                annotationID = MKAnnotationView(annotation: base1, reuseIdentifier: pinPuma)
            }
            if let annotationID = annotationID{
                annotationID.image = UIImage(named: "bus")
            }
            return annotationID
        }
        
        
        
        return nil
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}

