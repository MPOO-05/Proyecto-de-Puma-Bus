//
//  RegistroViewController.swift
//  PumaB
//
//  Created by Macbook on 6/5/18.
//  Copyright © 2018 Facultad de ingenieria. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class RegistroViewController: UIViewController {
    
    var ref = DatabaseReference()
   
    @IBOutlet weak var nombreC: UITextField!
    
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var contraseña: UITextField!
    
    @IBOutlet weak var contraseñaV: UITextField!
    
  
    override func viewDidLoad() {
        super.viewDidLoad()
ref = Database.database().reference()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func Registrar(_ sender: Any) {
    
        if let email = email.text, let password = contraseña.text, let passwordV = contraseñaV.text{
            
            
            
            if (password == passwordV && password.count>6 ){
            Auth.auth().createUser(withEmail: email, password: password){ (user, error) in
                if user != nil {
                    print("Usuario Creado")
                    
                    let values = ["email" : email]
                    
                    guard let uid = user?.uid else{return}
                    
                    let userReference  = self.ref.child("users").child(uid)
                    
                    //si existe lo actualiza sino lo creo
                    //self.ref.update....
                    userReference.updateChildValues(values, withCompletionBlock: { (error, databaseRef) in
                        if error != nil{
                            print("Error al insertar el valor")
                            return
                            
                        }else{
                            print("Todo salio bien y se guardaron nada mas")
                        }
                    })
                    
                    
                }else{
                    if let error = error?.localizedDescription{
                        print("Error de firebase al crear usuario")
                        
                    }else{
                        print("El error fui Yo :/")
                    }
                }
                }
            
            }
        
        }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
}
