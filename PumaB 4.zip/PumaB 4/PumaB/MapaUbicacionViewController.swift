//
//  MapaUbicacionViewController.swift
//  PumaB
//
//  Created by Macbook on 6/5/18.
//  Copyright © 2018 Facultad de ingenieria. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation // para la ubicacion del usuario

class MapaUbicacionViewController: UIViewController,MKMapViewDelegate, CLLocationManagerDelegate {
    var email = " "
   
  
    
    @IBOutlet weak var Mapa: MKMapView!
    
    
    @IBOutlet var boton1: UIButton!
    var LocationManager = CLLocationManager()
    var location: CLLocation?
    
    var updatingLocation = false
    var lastLocationError: Error?
    
    var center1 = CLLocationCoordinate2D()
    var center2 = CLLocationCoordinate2D()
    
    let base1 = MKPointAnnotation()
    let pumaBus = MKPointAnnotation()
    

    
    @IBAction func ruta1(_ sender: Any) {
            boton1.isEnabled = true
            boton1.backgroundColor = UIColor.green
            rutaSelec = 1
            center2.latitude = 19.3308
            center2.longitude = -99.1808
            let region1 = MKCoordinateRegion(center:center2 , span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02))
            self.Mapa.setRegion(region1, animated: true)
            Mapa.removeAnnotations(Mapa.annotations)
            
            for n in rutaN1 {
                let base1 = MKPointAnnotation()
                
                base1.title = dicBases[n]?.2
                base1.coordinate = CLLocationCoordinate2D(latitude: dicBases[n]?.0 as! Double, longitude: dicBases[n]?.1 as! Double)
                Mapa.addAnnotation( base1)
                Mapa.tintColor = UIColor.green
            }

    }
    /*
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segue2"{
            _ = segue.destination as! Mapa2TableViewController
        }
    }
*/
    @IBAction func ruta9(_ sender: Any) {
        
        rutaSelec = 9
        boton1.backgroundColor = UIColor.green
        center2.latitude = 19.3308
        center2.longitude = -99.1845
        let region1 = MKCoordinateRegion(center:center2 , span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02))
        self.Mapa.setRegion(region1, animated: true)
        Mapa.removeAnnotations(Mapa.annotations)
        for n in rutaN9 {
            let base1 = MKPointAnnotation()
            base1.title = dicBases[n]?.2
            base1.coordinate = CLLocationCoordinate2D(latitude: dicBases[n]?.0 as! Double, longitude: dicBases[n]?.1 as! Double)
            Mapa.addAnnotation( base1)
            Mapa.tintColor = UIColor.red
            
        }
    }
    
    @IBAction func voyenpuma(_ sender: Any) {
        
            print(rutaSelec)
            self.performSegue(withIdentifier: "segueMapa2", sender: self)
            
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(email)
        
        boton1.isEnabled = false
        boton1.backgroundColor = UIColor.red
        
        Mapa.showsUserLocation = true
        
        if CLLocationManager.locationServicesEnabled() == true {
            if CLLocationManager.authorizationStatus() == .restricted || CLLocationManager.authorizationStatus() == .denied || CLLocationManager.authorizationStatus() == .notDetermined{
                
                LocationManager.requestWhenInUseAuthorization()
            }
            
            LocationManager.desiredAccuracy = 1.0
            LocationManager.delegate = self
            LocationManager.startUpdatingLocation()
            
        }else{
            
            print("Prende tu GPS")
        }
        
        self.Mapa.delegate = self

        // Do any additional setup after loading the view.
    }
    
   /*
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        
        center1.latitude = locations[0].coordinate.latitude
        center1.longitude = locations[0].coordinate.longitude
        
        
        let region = MKCoordinateRegion(center: center1, span: MKCoordinateSpan(latitudeDelta: 0.0001, longitudeDelta:0.001))
        
        self.Mapa.setRegion(region, animated:false )
        
        // Imprime la coordenadas del usuario
        
        print(" Lat: \(center1.latitude) y Long \(center1.longitude) ")
        
    */
       /* Mapa.removeAnnotation(self.pumaBus)
        pumaBus.title = "Puma bus"
        pumaBus.coordinate = CLLocationCoordinate2D(latitude: locations[0].coordinate.latitude, longitude: locations[0].coordinate.longitude)
        */
        
       // Mapa.addAnnotation(pumaBus)
        
  //  }
    //funcion por si hay algun error
    /*
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Hay un error")
    }
    */


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segueMapa2"{
            let siguienteVista = segue.destination as! Mapa2ViewController
            siguienteVista.emailfirebase = email
            
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
