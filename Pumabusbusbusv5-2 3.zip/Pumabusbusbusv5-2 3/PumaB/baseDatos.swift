//
//  baseDatos.swift
//  PumaB
//
//  Created by macbookUser on 05/06/18.
//  Copyright © 2018 Facultad de ingenieria. All rights reserved.
//

import Foundation
var dicBases = [
    //Ruta 1
    1:(19.3244,-99.1748,"Módulo Metro Universidad"),
    2:(19.3282,-99.1749,"CENDI"),
    3:(19.3323,-99.1784,"Psiquiatría y salud mental"),
    4:(19.3308,-99.1808,"Facultad de Química"),
    5:(19.3308,-99.1834,"CELE"),
    6:(19.3308,-99.1845,"Facultad de Ingeniería"),
    7:(19.3305,-99.1868,"Facultad de Arquitectura"),
    8:(19.3327,-99.1894,"Rectoría"),
    9:(19.3345,-99.1891,"Facultad de Psicología"),
    10:(19.3346,-99.1878,"Facultad de Filosofía"),
    11:(19.3351,-99.1851,"Facultad de Derecho"),
    12:(19.3352,-99.1830,"Facultad de Economía"),
    13:(19.3347,-99.1808,"Facultad de Odontología"),
    14:(19.3330,-99.1788,"Facultad de Medicina"),
    15:(19.3296,-99.1760,"Facultad de Veterinaria"),
    16:(19.3265,-99.1751,"Facultad de Geofísica (Instituto)"),
    17:(19.3232,-99.1771,"Química Conjunto D y E"),
    18:(19.3249,-99.1750,"Módulo Metro Universidad Ruta 2"),
    19:(19.3226,-99.1791,"Facultad de Ciencias (Alumnos)"),
    20:(19.3301,-99.1891,"Facultad de Ciencias (Profesores)"),
    21:(19.3236,-99.1847,"Facultad de Contaduría y Administración"),
    22:(19.3233,-99.1867,"Escuela de Trabajo Social"),
    23:(19.3243,-99.1877,"Metrobús CU"),
    24:(19.3237,-99.1879,"Metrobús Dirección Universidad"),
    25:(19.3224,-99.1869,"Educación a Distancia"),
    26:(19.3229,-99.1840,"DGTIC"),
    27:(19.3222,-99.1790,"Ciencias dirección Universidad"),
    28:(19.3206,-99.1764,"Tienda UNAM dirección Sur"),
    29:(19.3177,-99.1764,"FCPyS dirección Sur"),
    30:(19.3172,-99.1807,"Investigaciones Jurídicas Sur"),
    31:(19.3154,-99.1863,"Biblioteca Nacional Sur"),
    32:(19.3144,-99.1863,"CCU sur"),
    33:(19.3103,-99.1861,"Posgrado Economía"),
    34:(19.3117,-99.1849,"DGIRE"),
    35:(19.3098,-99.1803,"Archivo General"),
    36:(19.3080,-99.1801,"Av. del Imán"),
    37:(19.3139,-99.1800,"Investigaciones Filosóficas"),
    38:(19.3141,-99.1814,"Investigaciones Filológicas"),
    39:(19.3115,-99.1821,"Universum"),
    40:(19.3119,-99.1847,"Teatro y Danza"),
    41:(19.3144,-99.1859,"MUAC"),
    42:(19.3158,-99.1861,"Biblioteca Nacional Norte"),
    43:(19.3168,-99.1804,"Investigaciones Jurídicas Norte"),
    44:(19.3291,-99.1797,"Invernadero"),
    45:(19.3271,-99.1809,"Camino Verde"),
    46:(19.3257,-99.1819,"Anexo de Ingeniería"),
    47:(19.3301,-99.1891,"MUCA"),
    48:(19.3175,-99.1762,"TVUNAM"),
    49:(19.3189,-99.1758,"CUEC"),
    50:(19.3231,-99.1753,"Tienda UNAM 3"),
    51:(19.3291,-99.1797,"Invernadero"),
    52:(19.3271,-99.1809,"Camino Verde"),
    53:(19.3247,-99.1752,"Módulo Metro Universidad Ruta 4"),
    54:(19.3267,-99.1881,"Estadio de Prácticas"),
    55:(19.3233,-99.1927,"Campos de Futbol I"),
    56:(19.3214,-99.1930,"Jardín Botánico"),
    57:(19.3233,-99.1921,"Campos de Futbol II"),
    58:(19.3257,-99.1819,"Anexo de Ingeniería"),
    59:(19.3301,-99.1891,"MUCA"),
    60:(19.3300,-99.1905,"Estacionamiento 8"),
    61:(19.3291,-99.1923,"Estacionamiento 7"),
    62:(19.3302,-99.1934,"Estacionamiento 6"),
    63:(19.3312,-99.1941,"Estacionamiento 4"),
    64:(19.3326,-99.1936,"Estacionamiento 3"),
    65:(19.3334,-99.1932,"Estacionamiento 2"),
    66:(19.3335,-99.1906,"Estacionamiento 1"),
    67:(19.3265,-99.1944,"Pista de Calentamiento 1"),
    68:(19.3263,-99.1948,"Pumitas"),
    69:(19.3231,-99.1897,"Investigaciones Biomédicas"),
    70:(19.3228,-99.1892,"MB2"),
    71:(19.3252,-99.1814,"Ciencias 3"),
    72:(19.3290,-99.1790,"Ciencias del Mar"),
    73:(19.3301,-99.1882,"Centro Médico"),
    74:(19.3304,-99.1863,"Alberca"),
    75:(19.3304,-99.1849,"Ingeniería dirección este"),
    76:(19.3304,-99.1826,"Frontones"),
    77:(19.3307,-99.1809,"IIMAS"),
    78:(19.3349,-99.1915,"Relaciones Laborales"),
    79:(19.3355,-99.1928,"Dirección General de Obras/Proveeduría"),
    80:(19.3337,-99.1970,"AAPAUNAM" ),
    81:(19.3141,-99.1815,"Coordinación de Humanidades")
]

let rutaN1 = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]
let rutaN2 = [18, 17, 19, 20, 21, 22, 23, 24, 25, 26, 27]
let rutaN3 = [1, 28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,48,49,50]
let rutaN4 = [53, 17, 19, 20, 21, 22, 23, 54, 55, 56, 57, 24, 25, 26, 27]
let rutaN5 = [1,2,3,13,12,11,10,9,14,15,16,17]
let rutaN6 = [21,22,23,54,59,60,61,62,63,64,65,66,55,67,68,69,56,57,69,70,24,25,26,20,71,72,51,58]
let rutaN7 = [66,9,10,11,12,13,14,4,5,6,7,60,61,62,63,64,65]
let rutaN8 = [66,73,74,75,76,77,51,52,58,21,22,23,54,59,60,61,62,63,64,65]
let rutaN9 = [23,54,47,8,9,10,11,12,13,14,44,46,21,22]
let rutaN10 = [34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,29,30,70,55,56,57,69,31,32,33]
let rutaN11 = [54,59,60,61,78,79,80,67,68,56,57,70]
let rutaExpress = [10,11,31,33,81,43]

var rutaSelec = 0
var rutaAnt = 0
var borraEnvioCoor = false

