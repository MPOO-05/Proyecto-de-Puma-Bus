//
//  Estructura.swift
//  Mapas2
//
//  Created by macbook on 22/05/18.
//  Copyright © 2018 fi. All rights reserved.
//

import Foundation
//import UIKit
//import MapKit
import CoreLocation

struct trazarRutas {
    
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
}
