//
//  GpsPumaBus.swift
//  PumaB
//
//  Created by Macbook on 6/8/18.
//  Copyright © 2018 Facultad de ingenieria. All rights reserved.
//

import Foundation

class GpsPumaBus {
    
    let usuarioCorreo : String
    let lat : String
    let long : String
    let velocidad : String
    
    init(usuarioCorreo : String ,lat: String, long: String, velocidad: String) {
        self.usuarioCorreo = usuarioCorreo
        self.lat = lat
        self.long = long
        self.velocidad = velocidad
    }
    
    
}



