//
//  ViewController.swift
//  PumaB
//
//  Created by Macbook on 6/4/18.
//  Copyright © 2018 Facultad de ingenieria. All rights reserved.
//


/*
 var Username = self.usernameField.text
 var Password = self.passwordField.text
 
 if (Username!.characters.count) < 5 || (Password!.characters.count < 5)
 {
 var alert = UIAlertView(title: "Inválido", message: "El Nombre de Usuario y la Contraseña deben tener al menos 5 caracteres", delegate: self, cancelButtonTitle: "ok")
 
 alert.show()
 */

import UIKit
import Firebase
import FirebaseDatabase

class ViewController: UIViewController {
    
    var Usuario: String = ""
    
    var ref: DatabaseReference!



    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var EntrasyRegistrarBoton: UIButton!

//    @IBAction func Resgitrarse(_ sender: Any) {
//        
//        //self.performSegue(withIdentifier: "segueRegistro", sender: self)
//    
//    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
         ref = Database.database().reference()
        
        
        
        
        
        
    
    }
    
    @IBAction func BotonRegistroEntrar(_ sender: Any) {
        
     
    
                if let email = usernameField.text, let password = passwordField.text{
                    
                    Auth.auth().signIn(withEmail: email, password: password) { (user, error) in
                        if user != nil{
                            
                            print("Usuario autenticado")
                            self.performSegue(withIdentifier: "segue", sender: self)
                            
                            
                            
                            
                            
                            
                        }else{
                            if let error = error?.localizedDescription{
                                print("Error de firebase al crear usuario")
                                
                            }else{
                                print("El error fui Yo :/")
                            }
                        }
                    }
                }
            }
        


    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segue"{
            let VistaMapa = segue.destination as! MapaUbicacionViewController
            if usernameField.text != nil{
                
            
            VistaMapa.email = String(usernameField.text!)
            }
        }
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

