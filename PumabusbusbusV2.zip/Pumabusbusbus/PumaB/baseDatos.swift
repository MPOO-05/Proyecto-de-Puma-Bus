//
//  baseDatos.swift
//  PumaB
//
//  Created by macbookUser on 05/06/18.
//  Copyright © 2018 Facultad de ingenieria. All rights reserved.
//

import Foundation
var dicBases = [
    
    1:(19.3244,-99.1748,"Módulo Metro Universidad"),
    2:(19.3282,-99.1749,"CENDI"),
    3:(19.3323,-99.1784,"Psiquiatría y salud mental"),
    4:(19.3308,-99.1808,"Facultad de Química"),
    5:(19.3308,-99.1834,"CELE"),
    6:(19.3308,-99.1845,"Facultad de Ingeniería"),
    7:(19.3305,-99.1868,"Facultad de Arquitectura"),
    8:(19.3327,-99.1894,"Rectoría"),
    9:(19.3345,-99.1891,"Facultad de psicología"),
    10:(19.3346,-99.1878,"Facultad de Filosofía"),
    11:(19.3351,-99.1851,"Facultad de Derecho"),
    12:(19.3352,-99.1830,"Facultad de Economía"),
    13:(19.3347,-99.1808,"Facultad de Odontología"),
    14:(19.3330,-99.1788,"Facultad de Medicina"),
    15:(19.3296,-99.1760,"Facultad de Veterinaria"),
    16:(19.3265,-99.1751,"Facultad de Geofísica (Instituto)"),
    17:(19.3232,-99.1771,"Química Conjunto D y E"),
    18:(19.3249,-99.1750,"Módulo Metro Universidad Ruta 2"),
    19:(19.3226,-99.1791,"Facultad de Ciencias (Alumnos)"),
    20:(19.3301,-99.1891,"Facultad de Ciencias (Profesores)"),
    21:(19.3236,-99.1847,"Facultad de Contaduría y Administración"),
    22:(19.3233,-99.1867,"Escuela de Trabajo Social"),
    23:(19.3243,-99.1877,"Metrobús CU"),
    24:(19.3237,-99.1879,"Metrobús dirección Universidad"),
    25:(19.3224,-99.1869,"Educación a distancia"),
    26:(19.3229,-99.1840,"DGTIC"),
    27:(19.3222,-99.1790,"Ciencias dirección Universidad"),
    47:(19.3301,-99.1891,"MUCA"),
    44:(19.3291,-99.1797,"Invernadero"),
    45:(19.3271,-99.1809,"Camino Verde"),
    46:(19.3257,-99.1819,"Anexo de Ingeniería"),
    53:(19.3247,-99.1752,"Módulo Metro Universidad Ruta 4"),
    54:(19.3267,-99.1881,"Estadio de Prácticas"),
    55:(19.3233,-99.1927,"Campos de Futbol I"),
    56:(19.3214,-99.1930,"Jardín Botánico"),
    57:(19.3233,-99.1921,"Campos de Futbol II"),
    
    
    
]

let rutaN4 = [53, 17, 19, 20, 21, 22, 23, 54, 55, 56, 57, 24, 25, 26, 27]

let rutaN1 = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]
let rutaN9 = [23,54,47,8,9,10,11,12,13,14,44,46,21,22]

let rutaN2 = [18, 17, 19, 20, 21, 22, 23, 24, 25, 26, 27]


var rutaSelec = 0
