//
//  ViewController.swift
//  PumaB
//
//  Created by Macbook on 6/4/18.
//  Copyright © 2018 Facultad de ingenieria. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class ViewController: UIViewController {
    
    var ref: DatabaseReference!

    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var EntrasyRegistrarBoton: UIButton!
    @IBOutlet weak var Registrarse: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
         ref = Database.database().reference()
    
    }
    
    @IBAction func BotonRegistroEntrar(_ sender: Any) {
        
        var Username = self.usernameField.text
        var Password = self.passwordField.text
        //Establece el minimo de caracteres necesarios para crear la cuenta
        if (Username!.characters.count) < 5 || (Password!.characters.count < 5)
        {
            var alert = UIAlertView(title: "Inválido", message: "El Nombre de Usuario y la Contraseña deben tener al menos 5 caracteres", delegate: self, cancelButtonTitle: "ok")
            
            alert.show()
        }else{
            func loginUser(){
                if let email = usernameField.text, let password = passwordField.text{
                    
                    Auth.auth().signIn(withEmail: email, password: password) { (user, error) in
                        if user != nil{
                            
                            print("Usuario autenticado")
                            
                            
                        }else{
                            if let error = error?.localizedDescription{
                                print("Error de firebase al crear usuario")
                                
                            }else{
                                print("El error fui Yo :/")
                            }
                        }
                    }
                }
            }
        }
    }

    @IBAction func BontonParaRegistrarse(_ sender: Any) {
        
        func creatUser(){
            if let email = usernameField.text, let password = passwordField.text{
                Auth.auth().createUser(withEmail: email, password: password){ (user, error) in
                    if user != nil {
                        print("Usuario Creado")
                        
                        let values = ["email" : email]
                        
                        guard let uid = user?.uid else{return}
                        
                        let userReference  = self.ref.child("users").child(uid)
                        
                        //si existe lo actualiza sino lo creo
                        //self.ref.update....
                        userReference.updateChildValues(values, withCompletionBlock: { (error, databaseRef) in
                            if error != nil{
                                print("Error al insertar el valor")
                                return
                                
                            }else{
                                print("Todo salio bien y se guardaron nada mas")
                            }
                        })
                        
                        
                    }else{
                        if let error = error?.localizedDescription{
                            print("Error de firebase al crear usuario")
                            
                        }else{
                            print("El error fui Yo :/")
                        }
                    }
                }
                
            }
        }
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

