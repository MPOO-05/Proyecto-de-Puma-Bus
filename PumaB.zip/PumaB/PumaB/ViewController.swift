//
//  ViewController.swift
//  PumaB
//
//  Created by Macbook on 6/4/18.
//  Copyright © 2018 Facultad de ingenieria. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class ViewController: UIViewController {
    
    var ref: DatabaseReference!

    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var EntrasyRegistrarBoton: UIButton!
    
    @IBOutlet weak var SegmentedControl: UISegmentedControl!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
         ref = Database.database().reference()
    
    }

    
    @IBAction func SegmentedControl(_ sender: Any) {
        if SegmentedControl.selectedSegmentIndex == 0{
            print("Iniciar Sesion")
           
        } else {
            print("crear usuario")
          
        }
    }
    
    @IBAction func BotonRegistroEntrar(_ sender: Any) {
        
        if SegmentedControl.selectedSegmentIndex == 0{
            print("Iniciar Sesion")
            loginUser()
        } else {
            print("crear usuario")
            creatUser()
        }
        
    }
    
    
    
    func creatUser(){
        if let email = emailTextField.text, let password = passwordTextField.text{
            Auth.auth().createUser(withEmail: email, password: password){ (user, error) in
                if user != nil {
                    print("Usuario Creado")
                    
                    let values = ["email" : email]
                    
                    guard let uid = user?.uid else{return}
                    
                    let userReference  = self.ref.child("users").child(uid)
                    
                    //si existe lo actualiza sino lo creo
                    //self.ref.update....
                    userReference.updateChildValues(values, withCompletionBlock: { (error, databaseRef) in
                        if error != nil{
                            print("Error al insertar el valor")
                            return
                            
                        }else{
                            print("Todo salio bien y se guardaron nada mas")
                        }
                    })
                    
                    
                }else{
                    if let error = error?.localizedDescription{
                        print("Error de firebase al crear usuario")
                        
                    }else{
                        print("El error fui Yo :/")
                    }
                }
            }
            
        }
    }
    
    func loginUser(){
        if let email = emailTextField.text, let password =
            passwordTextField.text{
            
            Auth.auth().signIn(withEmail: email, password: password) { (user, error) in
                if user != nil{
                    
                    print("Usuario autenticado")
                
                    
                }else{
                    if let error = error?.localizedDescription{
                        print("Error de firebase al crear usuario")
                        
                    }else{
                        print("El error fui Yo :/")
                    }
                }
            }
        }
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

