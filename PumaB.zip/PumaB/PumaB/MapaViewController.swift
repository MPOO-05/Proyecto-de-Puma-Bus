//
//  MapaViewController.swift
//  PumaB
//
//  Created by Macbook on 6/4/18.
//  Copyright © 2018 Facultad de ingenieria. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation // para la ubicacion del usuario
let dicBases = [1:(19.3244,-99.1748,"Módulo Metro Universidad",true),
                2:(19.3282,-99.1749,"CENDI",true),
                3:(19.3323,-99.1784,"Psiquiatría y salud mental",true),
                4:(19.3308,-99.1808,"Facultad de Química",true),
                5:(19.3308,-99.1834,"CELE",true),
                6:(19.3308,-99.1845,"Facultad de Ingeniería",true),
                7:(19.3305,-99.1868,"Facultad de Arquitectura",true),
                8:(19.3327,-99.1894,"Rectoría",true),
                9:(19.3345,-99.1891,"Facultad de psicología",true),
                10:(19.3346,-99.1878,"Facultad de Filosofía",true),
                11:(19.3351,-99.1851,"Facultad de Derecho",true),
                12:(19.3352,-99.1830,"Facultad de Economía",true),
                13:(19.3349,-99.1808,"Facultad de Odontología",true),
                14:(19.3330,-99.1788,"Facultad de Medicina",true),
                15:(19.3296,-99.1760,"Facultad de Veterinaria",true),
                16:(19.3265,-99.1751,"Facultad de Geofísica (Instituto)",true),
                17:(19.3232,-99.1771,"Química Conjunto D y E",true),
                21:(19.3236,-99.1847,"Facultad de Contaduría y Administración",true),
                22:(19.3233,-99.1867,"Escuela de Trabajo Social",true),
                23:(19.3243,-99.1877,"Metrobus CU",true),
                47:(19.3301,-99.1891,"MUCA",true),
                44:(19.3291,-99.1797,"Invernadero",true),
                45:(19.3271,-99.1809,"Camino Verde",true),
                46:(19.3257,-99.1819,"Anexo de Ingeniería",true),
                54:(19.3267,-99.1881,"Estadio de Prácticas",true),
                
]


let ruta1 = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]
let ruta9 = [23,54,47,8,9,10,11,12,13,14,44,46,21,22]


class customPin: NSObject, MKAnnotation{
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    init(pinTitle: String, pinSubTitle: String,location: CLLocationCoordinate2D){
        
        self.title = pinTitle
        self.subtitle = pinSubTitle
        self.coordinate = location
    }
    
}

class MapaViewController: UIViewController, MKMapViewDelegate,CLLocationManagerDelegate {

    @IBOutlet weak var Mapa: MKMapView!
    
    var LocationManager = CLLocationManager()
    
    var center1 = CLLocationCoordinate2D()
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Obteniendo mi ubicacion
        Mapa.showsUserLocation = true
        
        
        
        if CLLocationManager.locationServicesEnabled() == true {
            if CLLocationManager.authorizationStatus() == .restricted || CLLocationManager.authorizationStatus() == .denied || CLLocationManager.authorizationStatus() == .notDetermined{
                
                LocationManager.requestWhenInUseAuthorization()
            }
            
            LocationManager.desiredAccuracy = 1.0
            LocationManager.delegate = self
            LocationManager.startUpdatingLocation()
            
            
            
            
            
        }else{
            
            print("Prende tu GPS")
        }
        
        
        
        
        //Marcando la ruta 9
        
        
        
        let base1 = customPin(pinTitle: (dicBases[1]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[1]?.0)!, longitude: dicBases[1]!.1))
        let base2 = customPin(pinTitle: (dicBases[2]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[2]?.0)!, longitude: dicBases[2]!.1))
        let base3 = customPin(pinTitle: (dicBases[3]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[3]?.0)!, longitude: dicBases[3]!.1))
        let base4 = customPin(pinTitle: (dicBases[4]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[4]?.0)!, longitude: dicBases[4]!.1))
        let base5 = customPin(pinTitle: (dicBases[5]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[5]?.0)!, longitude: dicBases[5]!.1))
        let base6 = customPin(pinTitle: (dicBases[6]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[6]?.0)!, longitude: dicBases[6]!.1))
        let base7 = customPin(pinTitle: (dicBases[7]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[7]?.0)!, longitude: dicBases[7]!.1))
        let base8 = customPin(pinTitle: (dicBases[8]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[8]?.0)!, longitude: dicBases[8]!.1))
        let base9 = customPin(pinTitle: (dicBases[9]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[9]?.0)!, longitude: dicBases[9]!.1))
        let base10 = customPin(pinTitle: (dicBases[10]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[10]?.0)!, longitude: dicBases[10]!.1))
        let base11 = customPin(pinTitle: (dicBases[11]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[11]?.0)!, longitude: dicBases[11]!.1))
        let base12 = customPin(pinTitle: (dicBases[12]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[12]?.0)!, longitude: dicBases[12]!.1))
        let base13 = customPin(pinTitle: (dicBases[13]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[13]?.0)!, longitude: dicBases[13]!.1))
        let base14 = customPin(pinTitle: (dicBases[14]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[14]?.0)!, longitude: dicBases[14]!.1))
        let base15 = customPin(pinTitle: (dicBases[15]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[15]?.0)!, longitude: dicBases[15]!.1))
        let base16 = customPin(pinTitle: (dicBases[16]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[16]?.0)!, longitude: dicBases[16]!.1))
        let base17 = customPin(pinTitle: (dicBases[17]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[17]?.0)!, longitude: dicBases[17]!.1))
        let base21 = customPin(pinTitle: (dicBases[21]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[21]?.0)!, longitude: dicBases[21]!.1))
        let base22 = customPin(pinTitle: (dicBases[22]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[22]?.0)!, longitude: dicBases[22]!.1))
        let base23 = customPin(pinTitle: (dicBases[23]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[23]?.0)!, longitude: dicBases[23]!.1))
        let base47 = customPin(pinTitle: (dicBases[47]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[47]?.0)!, longitude: dicBases[47]!.1))
        let base44 = customPin(pinTitle: (dicBases[44]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[44]?.0)!, longitude: dicBases[44]!.1))
        let base45 = customPin(pinTitle: (dicBases[45]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[45]?.0)!, longitude: dicBases[45]!.1))
        let base46 = customPin(pinTitle: (dicBases[46]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[46]?.0)!, longitude: dicBases[46]!.1))
        let base54 = customPin(pinTitle: (dicBases[54]?.2)!, pinSubTitle: "", location: CLLocationCoordinate2D(latitude: (dicBases[54]?.0)!, longitude: dicBases[54]!.1))
        
        
        if(dicBases[1]!.3){self.Mapa.addAnnotation(base1)}
        if(dicBases[2]!.3){self.Mapa.addAnnotation(base2)}
        if(dicBases[3]!.3){self.Mapa.addAnnotation(base3)}
        if(dicBases[4]!.3){self.Mapa.addAnnotation(base4)}
        if(dicBases[5]!.3){self.Mapa.addAnnotation(base5)}
        if(dicBases[6]!.3){self.Mapa.addAnnotation(base6)}
        if(dicBases[7]!.3){self.Mapa.addAnnotation(base7)}
        if(dicBases[8]!.3){self.Mapa.addAnnotation(base8)}
        if(dicBases[9]!.3){self.Mapa.addAnnotation(base9)}
        if(dicBases[10]!.3){self.Mapa.addAnnotation(base10)}
        if(dicBases[11]!.3){self.Mapa.addAnnotation(base11)}
        if(dicBases[12]!.3){self.Mapa.addAnnotation(base12)}
        if(dicBases[13]!.3){self.Mapa.addAnnotation(base13)}
        if(dicBases[14]!.3){self.Mapa.addAnnotation(base14)}
        if(dicBases[15]!.3){self.Mapa.addAnnotation(base15)}
        if(dicBases[16]!.3){self.Mapa.addAnnotation(base16)}
        if(dicBases[17]!.3){self.Mapa.addAnnotation(base17)}
        if(dicBases[21]!.3){self.Mapa.addAnnotation(base21)}
        
        
        
        
        self.Mapa.addAnnotation(base22)
        self.Mapa.addAnnotation(base23)
        self.Mapa.addAnnotation(base47)
        self.Mapa.addAnnotation(base44)
        self.Mapa.addAnnotation(base45)
        self.Mapa.addAnnotation(base46)
        self.Mapa.addAnnotation(base54)
        
        
        let pM1 = MKPlacemark(coordinate: base1.coordinate)
        let pM2 = MKPlacemark(coordinate: base2.coordinate)
        let pM3 = MKPlacemark(coordinate: base3.coordinate)
        let pM4 = MKPlacemark(coordinate: base4.coordinate)
        let pM5 = MKPlacemark(coordinate: base5.coordinate)
        let pM6 = MKPlacemark(coordinate: base6.coordinate)
        let pM7 = MKPlacemark(coordinate: base7.coordinate)
        let pM8 = MKPlacemark(coordinate: base8.coordinate)
        let pM9 = MKPlacemark(coordinate: base9.coordinate)
        let pM10 = MKPlacemark(coordinate: base10.coordinate)
        let pM11 = MKPlacemark(coordinate: base11.coordinate)
        let pM12 = MKPlacemark(coordinate: base12.coordinate)
        let pM13 = MKPlacemark(coordinate: base13.coordinate)
        let pM14 = MKPlacemark(coordinate: base14.coordinate)
        let pM15 = MKPlacemark(coordinate: base15.coordinate)
        let pM16 = MKPlacemark(coordinate: base16.coordinate)
        let pM17 = MKPlacemark(coordinate: base17.coordinate)
        let pM21 = MKPlacemark(coordinate: base21.coordinate)
        let pM22 = MKPlacemark(coordinate: base22.coordinate)
        let pM23 = MKPlacemark(coordinate: base23.coordinate)
        let pM47 = MKPlacemark(coordinate: base47.coordinate)
        let pM44 = MKPlacemark(coordinate: base44.coordinate)
        let pM45 = MKPlacemark(coordinate: base45.coordinate)
        let pM46 = MKPlacemark(coordinate: base46.coordinate)
        let pM54 = MKPlacemark(coordinate: base54.coordinate)
        
        
        
        var MetroBusaEstadiodePracticas = MKDirectionsRequest()
        MetroBusaEstadiodePracticas = OrigenDestino(origen: pM1, destino: pM8, solicitudDireccion: MetroBusaEstadiodePracticas)
        
        var estadioDeParcticasaMUCA = MKDirectionsRequest()
        estadioDeParcticasaMUCA = OrigenDestino(origen: pM8, destino: pM17, solicitudDireccion: estadioDeParcticasaMUCA)
        
        var ruta1linea2 = MKDirectionsRequest()
        ruta1linea2 = OrigenDestino(origen: pM1, destino: pM17, solicitudDireccion: ruta1linea2)
        
        
        
        
        let d1 = MKDirections(request: MetroBusaEstadiodePracticas)
        AnotaRuta(directions: d1)
        
        let d2 = MKDirections(request: estadioDeParcticasaMUCA)
        AnotaRuta(directions: d2)
        
        let d3 = MKDirections(request: ruta1linea2)
        AnotaRuta(directions: d3)
        
        
        
        
        
        
        self.Mapa.delegate = self
        
        
    }
    
    
    func OrigenDestino(origen: MKPlacemark, destino: MKPlacemark, solicitudDireccion: MKDirectionsRequest) -> MKDirectionsRequest {
        
        let solicitudDireccion = MKDirectionsRequest()
        solicitudDireccion.source = MKMapItem(placemark: origen)
        solicitudDireccion.destination = MKMapItem(placemark: destino)
        
        solicitudDireccion.transportType = .automobile
        return solicitudDireccion
    }
    
    func AnotaRuta(directions : MKDirections) {
        
        directions.calculate { (response, error) in
            guard let directionResponse = response else{ if let error = error {
                print("Hay un error \(error.localizedDescription)")
                }
                return
                
            }
            let route = directionResponse.routes[0]
            self.Mapa.add(route.polyline, level: .aboveRoads)
            
            let rect = route.polyline.boundingMapRect
            self.Mapa.setRegion(MKCoordinateRegionForMapRect(rect), animated: true)
            
        }
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = UIColor.red
        renderer.lineWidth = 2.0
        
        return renderer
        
    }
    
    //FUNCION PARA OBTENER LA UBICACION DEK USUARIO
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        
        center1.latitude = locations[0].coordinate.latitude
        center1.longitude = locations[0].coordinate.longitude
        
        
        let region = MKCoordinateRegion(center: center1, span: MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005))
        //self.Mapa.setRegion(region, animated: true)
        // Imprime la coordenadas del usuario
        
        print(" Lat: \(center1.latitude) y Long \(center1.longitude) ")
        
    }
    //funcion por si hay algun error
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Hay un error")
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}


