//
//  baseDatos.swift
//  PumaB
//
//  Created by macbookUser on 05/06/18.
//  Copyright © 2018 Facultad de ingenieria. All rights reserved.
//

import Foundation
var dicBases = [1:(19.3244,-99.1748,"Módulo Metro Universidad",true),
                2:(19.3282,-99.1749,"CENDI",false),
                3:(19.3323,-99.1784,"Psiquiatría y salud mental",false),
                4:(19.3308,-99.1808,"Facultad de Química",false),
                5:(19.3308,-99.1834,"CELE",false),
                6:(19.3308,-99.1845,"Facultad de Ingeniería",false),
                7:(19.3305,-99.1868,"Facultad de Arquitectura",false),
                8:(19.3327,-99.1894,"Rectoría",false),
                9:(19.3345,-99.1891,"Facultad de psicología",false),
                10:(19.3346,-99.1878,"Facultad de Filosofía",false),
                11:(19.3351,-99.1851,"Facultad de Derecho",false),
                12:(19.3352,-99.1830,"Facultad de Economía",false),
                13:(19.3347,-99.1808,"Facultad de Odontología",false),
                14:(19.3330,-99.1788,"Facultad de Medicina",false),
                15:(19.3296,-99.1760,"Facultad de Veterinaria",false),
                16:(19.3265,-99.1751,"Facultad de Geofísica (Instituto)",false),
                17:(19.3232,-99.1771,"Química Conjunto D y E",false),
                21:(19.3236,-99.1847,"Facultad de Contaduría y Administración",false),
                22:(19.3233,-99.1867,"Escuela de Trabajo Social",false),
                23:(19.3243,-99.1877,"Metrobus CU",false),
                47:(19.3301,-99.1891,"MUCA",false),
                44:(19.3291,-99.1797,"Invernadero",false),
                45:(19.3271,-99.1809,"Camino Verde",false),
                46:(19.3257,-99.1819,"Anexo de Ingeniería",false),
                54:(19.3267,-99.1881,"Estadio de Prácticas",false),
                
]


let rutaN1 = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]
let rutaN9 = [23,54,47,8,9,10,11,12,13,14,44,46,21,22]

var rutaSelec = 0
