//
//  ViewController.swift
//  Mapas2
//
//  Created by Macbook on 14/05/18.
//  Copyright © 2018 fi. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation // para la ubicacion del usuario

class customPin: NSObject, MKAnnotation{
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?   
    init(pinTitle: String, pinSubTitle: String,location: CLLocationCoordinate2D){
        
        self.title = pinTitle
        self.subtitle = pinSubTitle
        self.coordinate = location
    }
    
}

class ViewController: UIViewController, MKMapViewDelegate,CLLocationManagerDelegate{
    
   @IBOutlet weak var Mapa: MKMapView!
    
    var LocationManager = CLLocationManager()
    
    var center1 = CLLocationCoordinate2D()
   
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
//Obteniendo mi ubicacion
        Mapa.showsUserLocation = true
        
    
        
        if CLLocationManager.locationServicesEnabled() == true {
            if CLLocationManager.authorizationStatus() == .restricted || CLLocationManager.authorizationStatus() == .denied || CLLocationManager.authorizationStatus() == .notDetermined{
                
                LocationManager.requestWhenInUseAuthorization()
            }
            
            LocationManager.desiredAccuracy = 1.0
            LocationManager.delegate = self
            LocationManager.startUpdatingLocation()
            
            



        }else{
            
            print("Prende tu GPS")
        }
            
       
     
        
//Marcando la ruta 9
        
        let metroBusCULocation = CLLocationCoordinate2D(latitude: 19.3243, longitude: -99.1877)
        let estadioDePracticasLocation = CLLocationCoordinate2D(latitude: 19.3267, longitude: -99.1881)
        let MUCALocation = CLLocationCoordinate2D(latitude: 19.3301, longitude: -99.1891)
        let rectoriaLocation = CLLocationCoordinate2D(latitude: 19.3327, longitude: -99.1894)
        let facPsicologiaLocation = CLLocationCoordinate2D(latitude: 19.3345, longitude: -99.1891)
        let facFilosofiaLocation = CLLocationCoordinate2D(latitude: 19.3347, longitude: -99.1878)
        let facDerechoLocation = CLLocationCoordinate2D(latitude: 19.3351, longitude: -99.1851)
        let facEconomiaLocation = CLLocationCoordinate2D(latitude: 19.3352, longitude: -99.1830)
        let facOdontologiaLocation = CLLocationCoordinate2D(latitude: 19.3347, longitude: -99.1808)
        let facMedicinaLocation = CLLocationCoordinate2D(latitude: 19.3330, longitude: -99.1788)
        let invernaderoLocation = CLLocationCoordinate2D(latitude: 19.3291, longitude: -99.1797)
        let caminoVerdeLocation = CLLocationCoordinate2D(latitude: 19.3271, longitude: -99.1809)
        let anexoDeIngenieriaLocation = CLLocationCoordinate2D(latitude: 19.3257, longitude: -99.1819)
        let facContaduriaLocation = CLLocationCoordinate2D(latitude: 19.3236, longitude: -99.1847)
        let trabajoSocialLocation = CLLocationCoordinate2D(latitude: 19.3233, longitude: -99.1867)
         
        
        
        let metroBusCU = customPin(pinTitle: "MetroBus CU", pinSubTitle: "", location: metroBusCULocation)
        let estadioDePracticas = customPin(pinTitle: "Estadio de Practicas", pinSubTitle: "", location: estadioDePracticasLocation)
        let MUCA = customPin(pinTitle: "MUCA", pinSubTitle: "", location: MUCALocation)
        let rectoria = customPin(pinTitle: "Rectoria", pinSubTitle: "", location: rectoriaLocation)
        let facPsicologia = customPin(pinTitle: "Facultad de Psicologia", pinSubTitle: "", location: facPsicologiaLocation)
        let facFilosofia = customPin(pinTitle: "Facultad de Filosofia", pinSubTitle: "", location: facFilosofiaLocation)
        let facDerecho = customPin(pinTitle: "Facultad de Derecho", pinSubTitle: "", location: facDerechoLocation)
        let facEconomia = customPin(pinTitle: "Facultad de Economia", pinSubTitle: "", location: facEconomiaLocation)
        let facOdontologia = customPin(pinTitle: "Facultad de Odontologia", pinSubTitle: "", location: facOdontologiaLocation)
        let facMedicina = customPin(pinTitle: "Facultad de Medicina", pinSubTitle: "", location: facMedicinaLocation)
        let invernadero = customPin(pinTitle: "Invernadero", pinSubTitle: "", location: invernaderoLocation)
        let caminoVerde = customPin(pinTitle: "Camino Verde", pinSubTitle: "", location: caminoVerdeLocation)
        let anexoDeIngenieria = customPin(pinTitle: "Anexo de Ingeniera", pinSubTitle: "", location: anexoDeIngenieriaLocation)
        let facContaduria = customPin(pinTitle: "Facultad de Contaduria y Administracion", pinSubTitle: "", location: facContaduriaLocation)
        let trabajoSocial = customPin(pinTitle: "Trabajo Social", pinSubTitle: "", location: trabajoSocialLocation)
        
        self.Mapa.addAnnotation(metroBusCU)
        self.Mapa.addAnnotation(estadioDePracticas)
        self.Mapa.addAnnotation(MUCA)
        self.Mapa.addAnnotation(rectoria)
        self.Mapa.addAnnotation(facPsicologia)
        self.Mapa.addAnnotation(facFilosofia)
        self.Mapa.addAnnotation(facDerecho)
        self.Mapa.addAnnotation(facEconomia)
        self.Mapa.addAnnotation(facOdontologia)
        self.Mapa.addAnnotation(facMedicina)
        self.Mapa.addAnnotation(invernadero)
        self.Mapa.addAnnotation(caminoVerde)
        self.Mapa.addAnnotation(anexoDeIngenieria)
        self.Mapa.addAnnotation(facContaduria)
        self.Mapa.addAnnotation(trabajoSocial)
        
    
        let metroBusCUPM = MKPlacemark(coordinate: metroBusCULocation)
        let estadioDePracticasPM = MKPlacemark(coordinate: estadioDePracticasLocation)
        let MUCAPM = MKPlacemark(coordinate: MUCALocation)
        let rectoriaPM = MKPlacemark(coordinate: rectoriaLocation)
        let facPsicologiaPM = MKPlacemark(coordinate: facPsicologiaLocation)
        let facFilosoficaPM = MKPlacemark(coordinate: facFilosofiaLocation)
        let facDerechoPM = MKPlacemark(coordinate: facDerechoLocation)
        let facEconomiaPM = MKPlacemark(coordinate: facEconomiaLocation)
        let facOdontologiaPM = MKPlacemark(coordinate: facOdontologiaLocation)
        let facMedicinaPM = MKPlacemark(coordinate: facMedicinaLocation)
        let InvernaderoPM = MKPlacemark(coordinate: invernaderoLocation)
        let caminoVerdePM = MKPlacemark(coordinate: caminoVerdeLocation)
        let anexodeIngenieriPM = MKPlacemark(coordinate: anexoDeIngenieriaLocation)
        let facContaduriaPM = MKPlacemark(coordinate: facContaduriaLocation)
        let trabajoSocialPM = MKPlacemark(coordinate: trabajoSocialLocation)
        
        
       
        var MetroBusaEstadiodePracticas = MKDirectionsRequest()
        MetroBusaEstadiodePracticas = OrigenDestino(origen: metroBusCUPM, destino: estadioDePracticasPM, solicitudDireccion: MetroBusaEstadiodePracticas)
      
        var estadioDeParcticasaMUCA = MKDirectionsRequest()
        estadioDeParcticasaMUCA = OrigenDestino(origen: estadioDePracticasPM, destino: MUCAPM, solicitudDireccion: estadioDeParcticasaMUCA)
        
        var MUCAaRectoria = MKDirectionsRequest()
        MUCAaRectoria = OrigenDestino(origen: MUCAPM, destino: rectoriaPM, solicitudDireccion: MUCAaRectoria)
 
        var RectoriaAPsicologia = MKDirectionsRequest()
            RectoriaAPsicologia = OrigenDestino(origen: rectoriaPM, destino: facPsicologiaPM, solicitudDireccion: RectoriaAPsicologia)
        
        var psicologiaaFilosofia = MKDirectionsRequest()
        psicologiaaFilosofia = OrigenDestino(origen: facPsicologiaPM, destino: facFilosoficaPM, solicitudDireccion: psicologiaaFilosofia)
        
        var filosofiaDerecho = MKDirectionsRequest()
        filosofiaDerecho = OrigenDestino(origen: facFilosoficaPM, destino: facDerechoPM, solicitudDireccion: filosofiaDerecho)
        
        var derechoEconomia = MKDirectionsRequest()
        derechoEconomia = OrigenDestino(origen: facDerechoPM, destino: facEconomiaPM, solicitudDireccion: derechoEconomia)
        
        var economiaOdontologia = MKDirectionsRequest()
        economiaOdontologia = OrigenDestino(origen: facEconomiaPM, destino: facOdontologiaPM, solicitudDireccion: economiaOdontologia)
        
        var odontologiaMedicina = MKDirectionsRequest()
        odontologiaMedicina = OrigenDestino(origen: facOdontologiaPM, destino: facMedicinaPM, solicitudDireccion: odontologiaMedicina)
        
        var medicinaInvernadero = MKDirectionsRequest()
        medicinaInvernadero = OrigenDestino(origen: facMedicinaPM, destino: InvernaderoPM, solicitudDireccion: medicinaInvernadero)
        
        var invernaderoCaminoverde = MKDirectionsRequest()
        invernaderoCaminoverde = OrigenDestino(origen: InvernaderoPM, destino: caminoVerdePM, solicitudDireccion: invernaderoCaminoverde)
        
        var CaminoverdeAnexoIng = MKDirectionsRequest()
        CaminoverdeAnexoIng =  OrigenDestino(origen: caminoVerdePM, destino: anexodeIngenieriPM, solicitudDireccion: CaminoverdeAnexoIng)
        
        var anexoIngContaduria = MKDirectionsRequest()
        anexoIngContaduria = OrigenDestino(origen: anexodeIngenieriPM, destino: facContaduriaPM, solicitudDireccion: anexoIngContaduria)
        
        var contaduriaTrabajoSocial = MKDirectionsRequest()
        contaduriaTrabajoSocial =  OrigenDestino(origen: facContaduriaPM, destino: trabajoSocialPM, solicitudDireccion: contaduriaTrabajoSocial)
        
        var trabajoSocialMetrobusCU = MKDirectionsRequest()
        trabajoSocialMetrobusCU = OrigenDestino(origen: trabajoSocialPM, destino: metroBusCUPM, solicitudDireccion: trabajoSocialMetrobusCU)
        
        
       
        let d1 = MKDirections(request: MetroBusaEstadiodePracticas)
       AnotaRuta(directions: d1)
        
        let d2 = MKDirections(request: estadioDeParcticasaMUCA)
      AnotaRuta(directions: d2)
        
        let d3 = MKDirections(request: MUCAaRectoria)
        AnotaRuta(directions: d3)
 
        
        let d4 = MKDirections(request: RectoriaAPsicologia)
        AnotaRuta(directions: d4)
        
        let d5 = MKDirections(request: psicologiaaFilosofia)
        let d6 = MKDirections(request: filosofiaDerecho)
        let d7 = MKDirections(request: derechoEconomia)
        let d8 = MKDirections(request: economiaOdontologia)
        let d9 = MKDirections(request: odontologiaMedicina)
        let d10 = MKDirections(request: medicinaInvernadero)
        let d11 = MKDirections(request: invernaderoCaminoverde)
        let d12 = MKDirections(request: CaminoverdeAnexoIng)
        let d13 = MKDirections(request: anexoIngContaduria)
        let d14 = MKDirections(request: contaduriaTrabajoSocial)
        let d15 = MKDirections(request: trabajoSocialMetrobusCU)
        
        AnotaRuta(directions: d5)
        AnotaRuta(directions: d6)
        AnotaRuta(directions: d7)
        AnotaRuta(directions: d8)
        AnotaRuta(directions: d9)
        AnotaRuta(directions: d10)
        AnotaRuta(directions: d11)
        AnotaRuta(directions: d12)
        AnotaRuta(directions: d13)
        AnotaRuta(directions: d14)
        AnotaRuta(directions: d15)
        
        
        
        self.Mapa.delegate = self
        
      
    }
   
    
    func OrigenDestino(origen: MKPlacemark, destino: MKPlacemark, solicitudDireccion: MKDirectionsRequest) -> MKDirectionsRequest {
        
        let solicitudDireccion = MKDirectionsRequest()
        solicitudDireccion.source = MKMapItem(placemark: origen)
        solicitudDireccion.destination = MKMapItem(placemark: destino)
        
        solicitudDireccion.transportType = .automobile
        return solicitudDireccion
    }
    
    func AnotaRuta(directions : MKDirections) {
        
        directions.calculate { (response, error) in
            guard let directionResponse = response else{ if let error = error {
                print("Hay un error \(error.localizedDescription)")
                }
                return
                
            }
            let route = directionResponse.routes[0]
            self.Mapa.add(route.polyline, level: .aboveRoads)
            
            let rect = route.polyline.boundingMapRect
            self.Mapa.setRegion(MKCoordinateRegionForMapRect(rect), animated: true)
            
        }
    }

    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = UIColor.red
        renderer.lineWidth = 2.0
        
        return renderer
    
    }
    
//FUNCION PARA OBTENER LA UBICACION DEK USUARIO
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
    
    
    center1.latitude = locations[0].coordinate.latitude
    center1.longitude = locations[0].coordinate.longitude

    
    let region = MKCoordinateRegion(center: center1, span: MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005))
        self.Mapa.setRegion(region, animated: true)
    // Imprime la coordenadas del usuario
        
    print(" Lat: \(center1.latitude) y Long \(center1.longitude) ")
        
    }
   //funcion por si hay algun error
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Hay un error")
    }

    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

